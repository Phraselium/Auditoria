#!/usr/bin/env python3
"""Punto de entrada de la libreria de calculo de auditoria-nia-es.

    python3 audita.py <subcomando> [argumentos]
    python3 audita.py doctor

Es Python plano, sin bit de ejecucion y sin instalar nada: el paquete no lleva
ningun script de shell ejecutable, para no disparar los controles de seguridad
de la plataforma.
"""
import os
import sys

RAIZ = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(RAIZ, "scripts"))
os.environ.setdefault("AUDITA_RAIZ", RAIZ)

try:
    import pandas  # noqa: F401
    import openpyxl  # noqa: F401
except ImportError as exc:
    print(f"Falta una dependencia de Python: {exc.name}.
"
          f"Instalela con:  {sys.executable} -m pip install pandas openpyxl
"
          f"Son las dos unicas que necesita el plugin.", file=sys.stderr)
    raise SystemExit(127)

from audita.cli import main  # noqa: E402

if __name__ == "__main__":
    raise SystemExit(main())
