---
name: auditoria-nia-es
description: 'Auditoría de cuentas anuales españolas bajo NIA-ES, ciclo completo: estimación de honorarios, aceptación e independencia, materialidad, mapa de riesgos, ingesta y cuadres de la contabilidad de cualquier ERP, las doce áreas de trabajo de campo (inmovilizado, existencias, clientes e ingresos, proveedores, tesorería y financiación, arrendamientos, fondos propios y reservas, personal, fiscal, provisiones, subvenciones y partes vinculadas), comparador documental de cuentas anuales y memoria, evaluación de incorrecciones, informe conforme a la Resolución del ICAC de 22/01/2026 y revisión de calidad del archivo. Todo cálculo por script, con traza a fichero, hoja y celda, y reporte por excepción. Úsala al trabajar en una auditoría española: cuadrar un balance de sumas y saldos, recalcular leasings o amortizaciones, fijar la materialidad, seleccionar una muestra, cuadrar la memoria, redactar el informe o revisar el archivo antes de firmar.'
---

# Auditoría de cuentas — NIA-ES

Equipo de auditoría senior para encargos españoles bajo NIA-ES. **Esta página es
el índice**: abre solo el procedimiento que necesites, cuando lo necesites.

Versión 1.6.0 · Marco: NIA-ES; PGC y PGC PYMES; RICAC de
22/01/2026 · Requiere Python 3.10+ con `pandas` y `openpyxl`.

## Cómo trabajar con esta skill

1. **Localiza la carpeta de la skill** una sola vez por conversación:
   ```bash
   find / -name 'SKILL.md' -path '*auditoria-nia-es*' 2>/dev/null | head -1
   ```
   Llámala `$D` (el directorio que la contiene). Todo lo demás es relativo a ella.

2. **Lee el procedimiento** que corresponda de la tabla de abajo:
   ```bash
   cat $D/procedimientos/<nombre>.md
   ```

3. **Ejecuta los cálculos** con la librería. Nunca calcules «a ojo»:
   ```bash
   python3 $D/audita.py doctor          # comprueba el entorno
   python3 $D/audita.py <subcomando> --help
   ```

4. **Antes de nada, carga las convenciones del despacho**:
   `cat $D/procedimientos/convenciones-despacho.md` — lleva los umbrales, el índice de
   papeles de trabajo, el marco normativo aplicado y las once reglas de
   comportamiento que no se negocian.

## Las once reglas que no se negocian

1. **El script calcula, tú interpretas.** Todo cuadre, recálculo, amortización,
   extrapolación de muestra o comparación numérica se ejecuta con la librería
   Python. Ningún importe sale de una estimación mental.
2. **Cero invención.** Ninguna cifra, fecha, cláusula o referencia normativa sin
   origen verificable. Si falta un dato: `[PENDIENTE-CLIENTE]`. Si hace falta
   criterio profesional: `[JUICIO-AUDITOR]`. Nunca se rellena en silencio.
3. **Reporte por excepción.** Conclusión + excepciones + evidencia. Nunca volcados
   masivos. Máximo 15 líneas en pantalla.
4. **Proporcionalidad graduada.** El alcance lo fija el perfil calculado del
   encargo (LIGERO / ESTÁNDAR / COMPLEJO), no una plantilla única.
5. **Justificabilidad.** Cada decisión metodológica queda documentada para que un
   revisor externo la reconstruya sin preguntar nada.
6. **Autocontrol.** Ningún procedimiento cierra sin pasar su checklist final.
7. **Asiste, no decide ni firma.** Toda conclusión es una propuesta sujeta a la
   validación del auditor firmante.
8. **Si la evidencia no basta, se dice.** Nunca se concluye igualmente.
9. **Nunca se recorta el alcance por debajo de lo defendible.** Si el atajo no es
   justificable, se dice y se propone la alternativa correcta con su coste.
10. **Confidencialidad.** La documentación del cliente está sujeta a deber de
    secreto (art. 31 LAC), a la normativa de blanqueo y al RGPD.
11. **Deja constancia** de que el trabajo se ha realizado con asistencia de
    herramientas automatizadas (NIGC1-ES).

> La dirección, supervisión y revisión del encargo es responsabilidad
> **indelegable** del socio firmante (NIA-ES 220 Revisada). Esta skill no la
> sustituye: la hace viable en minutos.

## Procedimientos disponibles

Cada uno en `procedimientos/<nombre>.md`. Ábrelos de uno en uno.

### Fase 0 — Captación y aceptación

| Procedimiento | Qué hace |
|---|---|
| **▸** `estimacion-y-aceptacion` | Perfil de complejidad, horas y honorarios, independencia, y el alcance que se activa. |
| `estimacion-encargo` | Calcula el perfil de complejidad y estima horas y honorarios, con punto muerto y go/no-go. |
| `aceptacion-e-independencia` | Evalúa independencia e incompatibilidades y genera la declaración firmable y la carta de encargo. |
| `escalado-del-encargo` | Configura el alcance según el perfil, y lo eleva si un hallazgo invalida la simplificación. |

### Fase 1 — Planificación

| Procedimiento | Qué hace |
|---|---|
| **▸** `planificacion` | Planificación completa — entendimiento, materialidad, riesgos, diseño de pruebas y PBC. |
| `entendimiento-entidad` | Perfil de negocio, marco contable aplicable, ciclos, sistemas de TI y partes vinculadas. |
| `materialidad` | Materialidad global, de ejecución y específicas, con la justificación del criterio elegido. |
| `mapa-de-riesgos` | Riesgos por área y afirmación, situados en el espectro de riesgo inherente y motivados. |
| `diseno-de-pruebas` | Elige para cada riesgo el procedimiento más barato que sigue siendo suficiente, con su fundamento. |
| `plan-y-solicitud-informacion` | Genera la PBC personalizada y priorizada por ruta crítica, y hace seguimiento de pendientes. |

### Fase 2 — Trabajo de campo (transversales)

| Procedimiento | Qué hace |
|---|---|
| **▸** `convenciones-despacho` | Configuración del despacho: umbrales, índice de papeles, marco normativo y reglas del plugin. |
| **▸** `ingesta-y-cuadres` | Normaliza la contabilidad de cualquier ERP y ejecuta los cuadres. Puerta de entrada obligatoria. |
| **▸** `comparador-documental` | Compara cuentas anuales, memoria, borradores e informe, y reporta solo las diferencias. |
| **▸** `tecnicas-de-prueba` | Muestreo, procedimientos analíticos y test de asientos del diario. |
| `muestreo` | Selecciona la muestra (MUS, atributos o dirigido) y proyecta los errores a la población. |
| `analiticos` | Procedimientos analíticos con el umbral de investigación fijado antes de mirar las cifras. |
| `test-asientos-diario` | Selecciona los asientos inusuales del diario. Obligatorio en todo encargo. |

### Fase 2 — Áreas

| Procedimiento | Qué hace |
|---|---|
| **▸** `areas-de-campo` | Ejecuta cualquier área de trabajo de campo con su programa escalado por perfil. |
| `area-inmovilizado` | Área A — Altas, bajas, recálculo integral de amortizaciones e indicios de deterioro. |
| `area-existencias` | Área B — Recuento físico, valoración, corte de operaciones y obsolescencia. |
| `area-clientes-e-ingresos` | Área C — Circularización, corte de operaciones, deterioro y reconocimiento de ingresos. |
| `area-proveedores-y-compras` | Área H — Conciliaciones, corte y búsqueda de pasivos no registrados. |
| `area-tesoreria-y-financiacion` | Áreas D y E — Conciliaciones bancarias, confirmaciones, deuda viva y covenants. |
| `area-arrendamientos` | Área F — Recalcula y clasifica cientos de contratos de leasing y saca el cuadro de vencimientos. |
| `area-fondos-propios-y-reservas` | Área G — Patrimonio neto y reservas indisponibles: legal, capitalización, nivelación. |
| `area-personal` | Área I — Concilia nóminas, seguros sociales y contabilidad; indemnizaciones y retenciones. |
| `area-fiscal` | Área J — Conciliación resultado contable ↔ base imponible, impuestos diferidos y cuadres fiscales. |
| `area-provisiones-y-contingencias` | Área K — Circulariza abogados y evalúa litigios, provisiones y pasivos contingentes. |
| `area-subvenciones` | Área L — Clasificación, condiciones, imputación a resultados y riesgo de reintegro. |
| `area-partes-vinculadas` | Área M — Identifica partes vinculadas, sus operaciones y el desglose de retribuciones. |
| `saldos-apertura` | Procedimientos sobre saldos iniciales en primeros encargos y su efecto en la opinión. |

### Fase 3 — Cierre e informe

| Procedimiento | Qué hace |
|---|---|
| **▸** `cierre-del-encargo` | Cierre — incorrecciones, hechos posteriores, empresa en funcionamiento, manifestaciones y archivo. |
| `hechos-posteriores-y-empresa-en-funcionamiento` | Hechos posteriores y empresa en funcionamiento, con su efecto directo en el informe. |
| `evaluacion-de-incorrecciones` | Sumario de ajustes corregidos y no corregidos, con su evaluación cualitativa y efecto en la opinión. |
| `comunicaciones-y-manifestaciones` | Carta de manifestaciones adaptada, deficiencias de control interno y comunicación con el gobierno. |
| `archivo-y-cierre` | Ensambla el archivo final: índice, referencias cruzadas, conservación y registro de uso de IA. |
| **▸** `redaccion-informe` | Determina el tipo de opinión y redacta el informe conforme a los modelos vigentes de 2026. |

### Transversal — seguimiento y revisión

| Procedimiento | Qué hace |
|---|---|
| **▸** `revision-de-calidad` | Estado del encargo, panel del socio y listado completo de excepciones por severidad. |
| `estado-del-encargo` | Dónde está el encargo, qué falta del cliente y cuál es el siguiente paso. |

**▸** marca las **guías de fase**: ábrelas primero, te dicen qué
procedimiento de su fase corresponde y en qué orden.

## Qué más hay en el paquete

| Carpeta | Contenido |
|---|---|
| `scripts/audita/` | La librería de cálculo: ingesta, cuadres, materialidad, muestreo, leasings, financiación, amortizaciones, comparador, test de asientos y revisión de calidad |
| `referencias/` | Mapeo del PGC a epígrafes, checklist de las 25 notas de memoria por modelo, catálogo de riesgos y los doce programas de trabajo por área |
| `plantillas/` | Modelo de informe conforme a la RICAC de 22/01/2026, cartas de encargo y de manifestaciones, comunicaciones y solicitudes de confirmación |

## Subcomandos de la librería

```
doctor       comprueba el entorno y la configuración
nuevo        crea la carpeta y el estado del encargo
estimar      perfil de complejidad, horas y honorarios
ingesta      normaliza la contabilidad y ejecuta los cuadres  ← empieza por aquí
materialidad materialidad global, de ejecución y específicas
leasing      procesa el lote de contratos de arrendamiento
financiacion cartera, confirmaciones bancarias y covenants
amortizaciones  recálculo integral del inmovilizado
reservas     reservas indisponibles y restringidas
asientos     test de asientos del diario (NIA-ES 240)
muestreo     MUS, atributos o dirigido, con semilla registrada
analiticos   variaciones, ratios y expectativas
comparar     comparador documental
calidad      revisión del archivo y panel del socio
estado       dónde está el encargo y cuál es el siguiente paso
horas / pbc / validar   seguimiento del encargo y bitácora de uso de IA
```

## Primer uso

Ejecuta `python3 $D/audita.py doctor`. Te dirá qué falta por configurar: los
campos entre `«»` de `procedimientos/convenciones-despacho.md` (números de ROAC,
ruta base), las tarifas por categoría y los párrafos del modelo de informe
pendientes de contrastar con el PDF oficial del ICAC.
